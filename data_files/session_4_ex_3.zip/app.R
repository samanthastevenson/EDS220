library(shiny)
library(shinydashboard)

ui <- dashboardPage(
  dashboardHeader(title = "Star Wars!"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Homeworld", tabName = "homes", icon = icon("jedi")),
      menuItem("Species", tabName = "species", icon = icon("pastafarianism"))
    )
  ),
  dashboardBody(
    tabItem(
      tabName = "Homeworld",
      fluidRow(

        box(title = "Homeworld graph",
            selectInput("sw_species", "Choose species to explore homeworlds:", choices = c(unique(starwars$species)))),

        box(plotOutput("sw_plot"))
      )
    )
  )
)

server <- function(input, output) {

  species_df <- reactive({
    starwars %>%
      filter(species == input$sw_species)
  })

  output$sw_plot <- renderPlot({
    ggplot(species_df(), aes(x = homeworld)) +
      geom_bar() +
      coord_flip()

  })


  }

shinyApp(ui, server)
